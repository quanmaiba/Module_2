﻿namespace GameLol.DoMain
{
    public class RoleSkinHero
    {
        public int HeroID { get; set; }
        public HeroLol HeroLol { get; set; }
        public int RoleSkinID { get; set; }
        public RoleSkin RoleSkin { get; set; }


    }
}
