﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GameLol.AppData.Migrations
{
    public partial class innit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
