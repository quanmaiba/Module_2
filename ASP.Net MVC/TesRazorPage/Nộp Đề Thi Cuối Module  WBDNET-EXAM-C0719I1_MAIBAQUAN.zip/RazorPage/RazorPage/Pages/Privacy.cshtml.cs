﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPage.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}