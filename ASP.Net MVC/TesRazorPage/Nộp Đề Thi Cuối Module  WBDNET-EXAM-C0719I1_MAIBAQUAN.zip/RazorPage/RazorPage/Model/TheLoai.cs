﻿namespace RazorPage.Model
{
    public partial class QuanLySach
    {
        public enum TheLoai
        {
            TieuThuyet,
            Truyen,
            VanHoa,
            ChinhTri,
            GiaoDuc
        }

    }
}
