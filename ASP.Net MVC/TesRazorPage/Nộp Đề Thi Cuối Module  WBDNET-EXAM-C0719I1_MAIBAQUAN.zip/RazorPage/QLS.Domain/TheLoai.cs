﻿namespace QLS.Domain
{
    partial class QuanLySach
    {
        public enum TheLoai
        {
            TieuThuyet,
            Truyen,
            VanHoa,
            ChinhTri,
            GiaoDuc
        }

    }
}
