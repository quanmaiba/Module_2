﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVCStudent.Models;
using MVCStudent.ViewModel;
using System.Linq;

namespace MVCStudent.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentRepository _studentRepository;
        private readonly IGroupRepository groupRepository;
        private readonly MvcContext mvcContext;

        public StudentController(IStudentRepository studentRepository, IGroupRepository groupRepository, MvcContext mvcContext)
        {
            _studentRepository = studentRepository;
            this.groupRepository = groupRepository;
            this.mvcContext = mvcContext;
        }
        //[BindProperty]
        //public Student Student { get; set; }
        [TempData]
        public string Message { get; set; }
        // GET: Student
        public IActionResult Index()
        {

            StudentsListViewModel studentsListViewModel = new StudentsListViewModel();
            studentsListViewModel.Students = _studentRepository.GetStudentsAll;
            return View(studentsListViewModel);
        }

        // GET: Student/Details/5
        public ActionResult Details(int id)
        {
            var student = _studentRepository.GetStudentById(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // GET: Student/Create
        public IActionResult Create()
        {
            var selects = groupRepository.GetStudentsAll();

            //ViewData["GroupId"] = new SelectList(selects);
            ViewBag.Hero = mvcContext.Groups.ToList();
            //ViewData["Group"] = new SelectList(selects).ToList();
            TempData["Message"] = null;

            return View();
        }

        // POST: Student/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                _studentRepository.AddStudent(student);

                var result = _studentRepository.Commit();

                if (result)
                {
                    TempData["Message"] = "Create Finish";
                }
                else
                {
                    TempData["Message"] = "Create Fails";
                }
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Student/Edit/5
        public IActionResult Edit(int id)
        {
            var selects = groupRepository.GetStudentsAll();
            ViewData["Group"] = mvcContext.Groups.ToList();
            TempData["Message"] = null;
            if (id == null)
            {
                return NotFound();
            }
            var student = _studentRepository.GetStudentById(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // POST: Student/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Student student)
        {
            if (id != student.StudentId)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _studentRepository.UpdateStudent(student);

                var result = _studentRepository.Commit();

                if (result)
                {
                    TempData["Message"] = "Update Finish";
                }
                else
                {
                    TempData["Message"] = "Update Fails";
                }
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Student/Delete/5
        public IActionResult Delete(int id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var student = _studentRepository.GetStudentById(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // POST: Student/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id, bool c)
        {            
            if (ModelState.IsValid)
            {
                _studentRepository.DeleteStudent(id);

                var result = _studentRepository.Commit();

                if (result)
                {
                    TempData["Message"] = "Delete Finish";
                }
                else
                {
                    TempData["Message"] = "Delete Fails";
                }
                return RedirectToAction(nameof(Index));
            }
            return View();
        }
    }
}