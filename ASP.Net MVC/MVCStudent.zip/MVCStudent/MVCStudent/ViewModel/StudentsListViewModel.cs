﻿using MVCStudent.Models;
using System.Collections.Generic;

namespace MVCStudent.ViewModel
{
    public class StudentsListViewModel
    {
        public IEnumerable<Student> Students { get; set; }
        public string CurrentGroup { get; set; }
        public Student Student { get; set; }
    }
}
