﻿namespace CompanyDemo.Core
{
    public enum CompanyType
    {
        CNTT,
        SaleHuman,
        Unknown,
        Traibao
    }
}
