﻿using Microsoft.EntityFrameworkCore;
using PokemonApp.Domain;
using System;

namespace PokemonApp.Data
{
    public class PokemonContext : DbContext
    {
        public DbSet<Pokemon> Pokemons { get; set; }
        public DbSet<Note> Notes { get; set; }
        public DbSet<Battle> Battles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;Database=PokemonCodeFirst;Trusted_Connection=True;");
        }
    }
}
